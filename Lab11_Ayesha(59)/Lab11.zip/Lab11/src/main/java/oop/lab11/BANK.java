/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.lab11;

/**
 *
 * @author AYESHA
 */

public class BANK {
    
  public  String Accountname;
    public String AccountNumber;
    public double  balance=15000;
    public void withdraw(double v1){
    balance=balance-v1;
    }
    public void deposit(double v2){
        balance=balance+v2;

    }
    
    
    
    
   /* public static void main(String args[]){
        
        Scanner input=new Scanner(System.in);
        double cash1=input.nextDouble();
        withdraw(cash1){
    };
           double cash2=input.nextDouble();
           deposit(cash2);

        
        
        
    }*/
    
}
